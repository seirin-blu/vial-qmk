# The Default Quark Layout
